#include "test.h"

int main() {
	TestSearchServer();
}
